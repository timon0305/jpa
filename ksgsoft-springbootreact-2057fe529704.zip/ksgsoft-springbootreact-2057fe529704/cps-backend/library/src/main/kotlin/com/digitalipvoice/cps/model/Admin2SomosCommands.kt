package com.digitalipvoice.cps.model

object Admin2SomosCommands{
    val start = "START_CONNECTIONS"
    val stop = "STOP_CONNECTIONS"
}