package com.digitalipvoice.cps.model

object SysConfigType {
    val LOGO = "logo"
    val BANNER = "banner"
    val FAVICON = "favicon"
    val TEMPORARY_DIRECTORY = "temporary"
}