maven_env
	for maven dependency environment
	in windows, please register environment variable (path, "maven_env\apache-maven-3.6.1-bin\apache-maven-3.6.1")
swagger_env
	for swagger code gen environment
	in windows, please register environment variable (path, "\swagger_env")