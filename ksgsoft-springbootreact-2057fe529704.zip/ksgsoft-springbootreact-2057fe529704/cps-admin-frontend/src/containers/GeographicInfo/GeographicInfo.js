import React from 'react';

class GeographicInfo extends React.Component {
  constructor(props){
    super(props);
  }

  render(){
    return(
      <div>
        Dashboard Menu!
      </div>
    )
  }
}

export default GeographicInfo;
