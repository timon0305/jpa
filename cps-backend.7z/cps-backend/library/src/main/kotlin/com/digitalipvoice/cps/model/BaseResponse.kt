package com.digitalipvoice.cps.model

/**
 * Base response class with message property
 */
data class BaseResponse(var msg:String = "")